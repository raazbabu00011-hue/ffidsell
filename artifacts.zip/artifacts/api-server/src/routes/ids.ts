import { Router } from "express";
import { db, ffIdsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getAuthUser } from "./profile";

const router = Router();

function calcSellPrice(primeLevel: number, ffLevel: number): number {
  if (primeLevel <= 2) return 0;
  if (primeLevel === 3) return ffLevel >= 60 ? 3000 : Math.round(3000 * ffLevel / 60);
  if (primeLevel === 4) return ffLevel >= 60 ? 6000 : Math.round(6000 * ffLevel / 60);
  if (primeLevel === 5) return ffLevel >= 60 ? 15000 : Math.round(15000 * ffLevel / 60);
  if (primeLevel === 6) return ffLevel >= 55 ? 22000 : Math.round(22000 * ffLevel / 55);
  if (primeLevel === 7) return 26000;
  if (primeLevel === 8) return 35000;
  return 0;
}

function formatId(row: typeof ffIdsTable.$inferSelect, sellerUsername?: string | null) {
  return {
    id: row.id,
    userId: row.userId,
    platform: row.platform,
    ffId: row.ffId,
    ffLevel: row.ffLevel,
    primeLevel: row.primeLevel,
    linkedNumber: row.linkedNumber ?? null,
    facebookPassword: row.facebookPassword ?? null,
    uid: row.uid ?? null,
    gmailLinked: row.gmailLinked ?? null,
    gmailPassword: row.gmailPassword ?? null,
    upiId: row.upiId ?? null,
    sellPrice: row.sellPrice,
    buyPrice: row.buyPrice,
    status: row.status,
    sellerUsername: sellerUsername ?? null,
    createdAt: row.createdAt.toISOString(),
  };
}

// GET /api/ids — admin only, all IDs
router.get("/ids", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user || !user.isAdmin) return res.status(403).json({ error: "Forbidden" });
  const rows = await db
    .select({ id: ffIdsTable, user: usersTable })
    .from(ffIdsTable)
    .leftJoin(usersTable, eq(ffIdsTable.userId, usersTable.id));
  const result = rows.map((r) => formatId(r.id, r.user?.username));
  return res.json(result);
});

// POST /api/ids — submit for sell
router.post("/ids", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const { platform, ffId, ffLevel, primeLevel, linkedNumber, facebookPassword, uid, gmailLinked, gmailPassword, upiId } = req.body;
  if (!platform || !ffId || !ffLevel || !primeLevel) {
    return res.status(400).json({ error: "Required fields missing" });
  }
  const sellPrice = calcSellPrice(Number(primeLevel), Number(ffLevel));
  const buyPrice = Math.round(sellPrice / 2);
  const [row] = await db.insert(ffIdsTable).values({
    userId: user.id,
    platform,
    ffId,
    ffLevel: Number(ffLevel),
    primeLevel: Number(primeLevel),
    linkedNumber: linkedNumber ?? null,
    facebookPassword: facebookPassword ?? null,
    uid: uid ?? null,
    gmailLinked: gmailLinked ?? null,
    gmailPassword: gmailPassword ?? null,
    upiId: upiId ?? null,
    sellPrice,
    buyPrice,
    status: "pending",
  }).returning();
  return res.status(201).json(formatId(row, user.username));
});

// GET /api/ids/my
router.get("/ids/my", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const rows = await db.select().from(ffIdsTable).where(eq(ffIdsTable.userId, user.id));
  return res.json(rows.map((r) => formatId(r, user.username)));
});

// GET /api/ids/:id — only owner or admin
router.get("/ids/:id", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const id = Number(req.params.id);
  const rows = await db
    .select({ id: ffIdsTable, user: usersTable })
    .from(ffIdsTable)
    .leftJoin(usersTable, eq(ffIdsTable.userId, usersTable.id))
    .where(eq(ffIdsTable.id, id));
  if (rows.length === 0) return res.status(404).json({ error: "Not found" });
  const listing = rows[0];
  // Only owner or admin can view
  if (listing.id.userId !== user.id && !user.isAdmin) {
    return res.status(403).json({ error: "Forbidden" });
  }
  return res.json(formatId(listing.id, listing.user?.username));
});

export default router;
