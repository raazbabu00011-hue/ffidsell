import { Router } from "express";
import { db, usersTable, ffIdsTable, messagesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getAuthUser } from "./profile";
import { formatUser } from "./auth";
import { formatMessage } from "./messages";

const router = Router();

async function requireAdmin(req: import("express").Request, res: import("express").Response) {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) {
    res.status(401).json({ error: "Unauthorized" });
    return null;
  }
  if (!user.isAdmin) {
    res.status(403).json({ error: "Forbidden" });
    return null;
  }
  return user;
}

function formatAdminId(row: typeof ffIdsTable.$inferSelect, seller?: any) {
  return {
    id: row.id,
    userId: row.userId,
    platform: row.platform,
    ffId: row.ffId,
    ffLevel: row.ffLevel,
    primeLevel: row.primeLevel,
    linkedNumber: row.linkedNumber ?? null,
    facebookPassword: row.facebookPassword ?? null,
    uid: row.uid ?? null,
    gmailLinked: row.gmailLinked ?? null,
    gmailPassword: row.gmailPassword ?? null,
    upiId: row.upiId ?? null,
    sellPrice: row.sellPrice,
    buyPrice: row.buyPrice,
    status: row.status,
    sellerUsername: seller?.username ?? null,
    sellerPhone: seller?.phone ?? null,
    sellerEmail: seller?.email ?? null,
    createdAt: row.createdAt.toISOString(),
  };
}

// GET /api/admin/users
router.get("/admin/users", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const users = await db.select().from(usersTable);
  return res.json(users.map(formatUser));
});

// GET /api/admin/ids
router.get("/admin/ids", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const ids = await db
    .select({ id: ffIdsTable, user: usersTable })
    .from(ffIdsTable)
    .leftJoin(usersTable, eq(ffIdsTable.userId, usersTable.id));
  return res.json(ids.map((r) => formatAdminId(r.id, r.user)));
});

// PATCH /api/admin/ids/:id/approve
router.patch("/admin/ids/:id/approve", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const id = Number(req.params.id);
  const { status } = req.body;
  if (!["approved", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Invalid status" });
  }
  const dbStatus = status === "rejected" ? "pending" : status;

  // Get the listing first to know seller and price
  const listings = await db.select().from(ffIdsTable).where(eq(ffIdsTable.id, id));
  if (listings.length === 0) return res.status(404).json({ error: "Not found" });
  const listing = listings[0];

  const [updated] = await db.update(ffIdsTable).set({ status: dbStatus }).where(eq(ffIdsTable.id, id)).returning();

  // When approved, add sellPrice to seller's balance
  if (dbStatus === "approved") {
    const sellers = await db.select().from(usersTable).where(eq(usersTable.id, listing.userId));
    if (sellers.length > 0) {
      const seller = sellers[0];
      await db.update(usersTable)
        .set({ balance: (seller.balance || 0) + (listing.sellPrice || 0) })
        .where(eq(usersTable.id, listing.userId));
    }
  }

  return res.json(formatAdminId(updated));
});

// GET /api/admin/messages
router.get("/admin/messages", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const msgs = await db.select().from(messagesTable);
  return res.json(msgs.map(formatMessage));
});

// POST /api/admin/messages/:id/reply
router.post("/admin/messages/:id/reply", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const originalId = Number(req.params.id);
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: "Text required" });
  // Find the original message to get the userId
  const origMsgs = await db.select().from(messagesTable).where(eq(messagesTable.id, originalId));
  if (origMsgs.length === 0) return res.status(404).json({ error: "Message not found" });
  const original = origMsgs[0];
  const [row] = await db.insert(messagesTable).values({
    userId: original.userId,
    senderName: "Admin",
    text,
    isAdmin: true,
  }).returning();
  return res.status(201).json(formatMessage(row));
});

// DELETE /api/admin/users/:id — delete user
router.delete("/admin/users/:id", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const id = Number(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  // Don't delete self
  if (id === admin.id) return res.status(400).json({ error: "Cannot delete yourself" });
  await db.delete(messagesTable).where(eq(messagesTable.userId, id));
  await db.delete(ffIdsTable).where(eq(ffIdsTable.userId, id));
  await db.delete(usersTable).where(eq(usersTable.id, id));
  return res.json({ success: true });
});

// DELETE /api/admin/ids/:id — delete ID
router.delete("/admin/ids/:id", async (req, res) => {
  const admin = await requireAdmin(req, res);
  if (!admin) return;
  const id = Number(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  await db.delete(ffIdsTable).where(eq(ffIdsTable.id, id));
  return res.json({ success: true });
});

export default router;
