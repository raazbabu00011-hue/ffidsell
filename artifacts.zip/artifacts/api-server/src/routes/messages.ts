import { Router } from "express";
import { db, messagesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getAuthUser } from "./profile";

const router = Router();

function formatMessage(m: typeof messagesTable.$inferSelect) {
  return {
    id: m.id,
    userId: m.userId,
    senderName: m.senderName,
    text: m.text,
    isAdmin: m.isAdmin,
    createdAt: m.createdAt.toISOString(),
  };
}

// GET /api/messages — user's own messages
router.get("/messages", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const rows = await db.select().from(messagesTable).where(eq(messagesTable.userId, user.id));
  return res.json(rows.map(formatMessage));
});

// POST /api/messages
router.post("/messages", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: "Text required" });
  const [row] = await db.insert(messagesTable).values({
    userId: user.id,
    senderName: user.username,
    text,
    isAdmin: false,
  }).returning();
  return res.status(201).json(formatMessage(row));
});

export { formatMessage };
export default router;
