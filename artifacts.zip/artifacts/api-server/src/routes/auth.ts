import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import * as crypto from "crypto";
import * as jwt from "jsonwebtoken";

const router = Router();

const JWT_SECRET = process.env.SESSION_SECRET || "ff-id-store-secret";

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password + "ff_salt").digest("hex");
}

function signToken(userId: number): string {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "30d" });
}

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    username: user.username,
    phone: user.phone ?? null,
    email: user.email ?? null,
    photoUrl: user.photoUrl ?? null,
    isAdmin: user.isAdmin,
    balance: user.balance,
    pendingBalance: user.pendingBalance,
    createdAt: user.createdAt.toISOString(),
  };
}

// POST /api/auth/register
router.post("/auth/register", async (req, res) => {
  const { username, phone, email, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: "Username and password required" });
  }
  if (!phone && !email) {
    return res.status(400).json({ error: "Phone or email required" });
  }
  const passwordHash = hashPassword(password);
  const values: any = { username, passwordHash };
  if (phone) {
    const existing = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
    if (existing.length > 0) {
      return res.status(400).json({ error: "Phone already registered" });
    }
    values.phone = phone;
  }
  if (email) {
    const existing = await db.select().from(usersTable).where(eq(usersTable.email, email));
    if (existing.length > 0) {
      return res.status(400).json({ error: "Email already registered" });
    }
    values.email = email;
  }
  const [user] = await db.insert(usersTable).values(values).returning();
  const token = signToken(user.id);
  return res.status(201).json({ user: formatUser(user), token });
});

// POST /api/auth/login
router.post("/auth/login", async (req, res) => {
  const { phone, email, password } = req.body;
  if (!password) {
    return res.status(400).json({ error: "Password required" });
  }
  if (!phone && !email) {
    return res.status(400).json({ error: "Phone or email required" });
  }
  // Check admin login
  if (phone === "8874012067" && password === "raaz86011") {
    const admins = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
    if (admins.length === 0) {
      const [admin] = await db.insert(usersTable).values({
        username: "Admin",
        phone: "8874012067",
        passwordHash: hashPassword("raaz86011"),
        isAdmin: true,
      }).returning();
      const token = signToken(admin.id);
      return res.json({ user: formatUser(admin), token });
    }
    // Update isAdmin if not set
    if (!admins[0].isAdmin) {
      await db.update(usersTable).set({ isAdmin: true }).where(eq(usersTable.id, admins[0].id));
      admins[0].isAdmin = true;
    }
    const token = signToken(admins[0].id);
    return res.json({ user: formatUser(admins[0]), token });
  }
  let users: any[] = [];
  if (phone) {
    users = await db.select().from(usersTable).where(eq(usersTable.phone, phone));
  } else if (email) {
    users = await db.select().from(usersTable).where(eq(usersTable.email, email));
  }
  if (users.length === 0) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const user = users[0];
  if (user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = signToken(user.id);
  return res.json({ user: formatUser(user), token });
});

// POST /api/auth/logout
router.post("/auth/logout", (_req, res) => {
  return res.json({ message: "Logged out" });
});

// GET /api/auth/me
router.get("/auth/me", async (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const token = authHeader.slice(7);
  let payload: { userId: number };
  try {
    payload = jwt.verify(token, JWT_SECRET) as { userId: number };
  } catch {
    return res.status(401).json({ error: "Invalid token" });
  }
  const users = await db.select().from(usersTable).where(eq(usersTable.id, payload.userId));
  if (users.length === 0) {
    return res.status(401).json({ error: "User not found" });
  }
  return res.json(formatUser(users[0]));
});

export { JWT_SECRET, formatUser };
export default router;
