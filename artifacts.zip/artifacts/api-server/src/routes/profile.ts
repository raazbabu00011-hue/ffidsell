import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, gt } from "drizzle-orm";
import * as jwt from "jsonwebtoken";
import { JWT_SECRET, formatUser } from "./auth";

const router = Router();

async function getAuthUser(authHeader: string | undefined) {
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7);
  try {
    const payload = jwt.verify(token, JWT_SECRET) as { userId: number };
    const users = await db.select().from(usersTable).where(eq(usersTable.id, payload.userId));
    return users[0] ?? null;
  } catch {
    return null;
  }
}

// PATCH /api/profile
router.patch("/profile", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const { username, photoUrl } = req.body;
  const updates: Partial<typeof usersTable.$inferInsert> = {};
  if (username) updates.username = username;
  if (photoUrl !== undefined) updates.photoUrl = photoUrl;
  const [updated] = await db.update(usersTable).set(updates).where(eq(usersTable.id, user.id)).returning();
  return res.json(formatUser(updated));
});

// POST /api/profile/withdraw — move balance to pending
router.post("/profile/withdraw", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  const amount = req.body.amount ?? user.balance;
  if (amount <= 0 || amount > user.balance) {
    return res.status(400).json({ error: "Insufficient balance" });
  }
  const [updated] = await db.update(usersTable)
    .set({
      balance: user.balance - amount,
      pendingBalance: (user.pendingBalance || 0) + amount,
    })
    .where(eq(usersTable.id, user.id))
    .returning();
  return res.json(formatUser(updated));
});

// GET /api/admin/withdrawals — admin only
router.get("/admin/withdrawals", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user || !user.isAdmin) return res.status(403).json({ error: "Forbidden" });
  const rows = await db.select().from(usersTable).where(gt(usersTable.pendingBalance, 0));
  return res.json(rows.map(formatUser));
});

// POST /api/admin/withdrawals/:id/approve — admin only
router.post("/admin/withdrawals/:id/approve", async (req, res) => {
  const user = await getAuthUser(req.headers.authorization);
  if (!user || !user.isAdmin) return res.status(403).json({ error: "Forbidden" });
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid ID" });
  const [updated] = await db.update(usersTable)
    .set({ pendingBalance: 0 })
    .where(eq(usersTable.id, id))
    .returning();
  if (!updated) return res.status(404).json({ error: "User not found" });
  return res.json(formatUser(updated));
});

export { getAuthUser };
export default router;
