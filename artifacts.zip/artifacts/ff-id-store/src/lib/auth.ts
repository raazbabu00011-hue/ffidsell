export function getToken(): string | null {
  return localStorage.getItem("ff_token");
}

export function setToken(token: string) {
  localStorage.setItem("ff_token", token);
}

export function clearToken() {
  localStorage.removeItem("ff_token");
}
