export function calculateSellPrice(primeLevel: number, ffLevel: number): number {
  if (primeLevel <= 2) return 0;

  // Level bonus: every 10 levels above minimum = +10%
  function withLevelBonus(base: number, minLevel: number): number {
    if (ffLevel < minLevel) return Math.round(base / 2);
    const extraLevels = ffLevel - minLevel;
    const bonus = Math.min(Math.floor(extraLevels / 10) * 0.1, 0.5); // max 50% bonus
    return Math.round(base * (1 + bonus));
  }

  if (primeLevel === 3) return withLevelBonus(3000, 60);
  if (primeLevel === 4) return withLevelBonus(6000, 60);
  if (primeLevel === 5) return withLevelBonus(15000, 60);
  if (primeLevel === 6) return withLevelBonus(22000, 55);
  if (primeLevel === 7) return withLevelBonus(26000, 1);
  if (primeLevel === 8) return withLevelBonus(35000, 1);

  return 0;
}

export function calculateBuyPrice(sellPrice: number): number {
  return Math.round(sellPrice / 2);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}
