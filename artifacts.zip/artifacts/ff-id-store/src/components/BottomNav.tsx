import { useLocation, Link } from "wouter";

const tabs = [
  { path: "/home", label: "Home", icon: (active: boolean) => (
    <svg className={`w-6 h-6 ${active ? "text-purple-400" : "text-muted-foreground"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
  )},
  { path: "/orders", label: "Orders", icon: (active: boolean) => (
    <svg className={`w-6 h-6 ${active ? "text-purple-400" : "text-muted-foreground"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
  )},
  { path: "/sell", label: "Sell", icon: (active: boolean) => (
    <svg className={`w-6 h-6 ${active ? "text-purple-400" : "text-muted-foreground"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
  )},
  { path: "/profile", label: "Profile", icon: (active: boolean) => (
    <svg className={`w-6 h-6 ${active ? "text-purple-400" : "text-muted-foreground"}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
  )},
];

export default function BottomNav() {
  const [location] = useLocation();

  // Don't show on landing, login, register, not-found, admin, support, buy-id, my-ids
  const hiddenPaths = ["/", "/login", "/register", "/admin", "/support", "/my-ids"];
  const isDetailPage = location.startsWith("/orders/");
  if (hiddenPaths.includes(location) || isDetailPage) return null;

  return (
    <nav className="sticky bottom-0 z-50 bg-background/95 backdrop-blur border-t border-purple-500/10 pb-safe">
      <div className="flex items-center justify-around h-16">
        {tabs.map((tab) => {
          const isActive = location === tab.path;
          return (
            <Link key={tab.path} href={tab.path} className="flex flex-col items-center justify-center gap-0.5 flex-1 h-full">
              {tab.icon(isActive)}
              <span className={`text-[10px] font-bold ${isActive ? "text-purple-400" : "text-muted-foreground"}`}>{tab.label}</span>
              {isActive && <div className="absolute bottom-0 w-8 h-0.5 bg-purple-500 rounded-full" />}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
