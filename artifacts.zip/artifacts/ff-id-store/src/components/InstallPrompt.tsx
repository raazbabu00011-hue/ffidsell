import { useState, useEffect } from "react";

export default function InstallPrompt() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    const isIos = /iPhone|iPad|iPod/.test(navigator.userAgent);
    const isStandalone = window.matchMedia("(display-mode: standalone)").matches || (window as any).navigator.standalone;
    if (isIos && !isStandalone) {
      setShow(true);
    }
  }, []);

  if (!show) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 bg-[#1a1625] border border-purple-500/20 rounded-xl p-3 shadow-xl">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-purple-600 flex items-center justify-center text-white font-black text-lg">G</div>
        <div className="flex-1">
          <p className="text-sm font-bold text-white">Grenaid ko App ki tarah use karo!</p>
          <p className="text-xs text-muted-foreground">Safari ke Share button daba kar "Add to Home Screen" karein</p>
        </div>
        <button onClick={() => setShow(false)} className="text-muted-foreground hover:text-white text-lg leading-none">&times;</button>
      </div>
    </div>
  );
}
