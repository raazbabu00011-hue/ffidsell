import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useGetMe, getGetMeQueryKey, useUpdateProfile, useListMyIds, getListMyIdsQueryKey, useLogout } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQueryClient } from "@tanstack/react-query";
import { clearToken } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/pricing";

export default function Profile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editMode, setEditMode] = useState(false);
  const [newUsername, setNewUsername] = useState("");

  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: myIds } = useListMyIds({ query: { queryKey: getListMyIdsQueryKey() } });
  const updateProfile = useUpdateProfile();
  const logout = useLogout();

  useEffect(() => {
    if (error) { clearToken(); setLocation("/"); }
  }, [error, setLocation]);

  useEffect(() => {
    if (user) setNewUsername(user.username);
  }, [user]);

  const handleUpdate = () => {
    if (!newUsername.trim()) return;
    updateProfile.mutate({ data: { username: newUsername.trim() } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
        toast({ title: "Profile updated" });
        setEditMode(false);
      },
      onError: () => toast({ title: "Failed to update", variant: "destructive" }),
    });
  };

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSettled: () => {
        clearToken();
        queryClient.clear();
        setLocation("/");
        toast({ title: "Logged out" });
      }
    });
  };

  const soldCount = myIds?.filter(i => i.status === "sold").length ?? 0;
  const boughtCount = 0;
  const totalEarned = myIds?.filter(i => i.status === "sold").reduce((sum, i) => sum + i.sellPrice, 0) ?? 0;

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  return (
    <div className="flex flex-col flex-1 pb-6">
      <div className="p-4 border-b border-purple-500/10 bg-gradient-to-b from-purple-900/20 to-transparent">
        <h1 className="text-lg font-black uppercase tracking-wider">My Profile</h1>
      </div>

      {/* Profile header */}
      <div className="px-6 pt-6 pb-4 flex flex-col items-center">
        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-600 to-purple-900 border-2 border-purple-500/30 flex items-center justify-center text-3xl font-black text-white mb-3 shadow-lg shadow-purple-500/20">
          {user.photoUrl ? (
            <img src={user.photoUrl} alt="Profile" className="w-full h-full rounded-full object-cover" />
          ) : (
            user.username.substring(0, 2).toUpperCase()
          )}
        </div>

        {editMode ? (
          <div className="w-full max-w-xs flex flex-col gap-2">
            <Input value={newUsername} onChange={e => setNewUsername(e.target.value)} className="bg-[#1a1625] border-purple-500/20 h-10 text-center" />
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="flex-1 h-9 border-purple-500/20" onClick={() => setEditMode(false)}>Cancel</Button>
              <Button size="sm" className="flex-1 h-9 bg-purple-600" onClick={handleUpdate} disabled={updateProfile.isPending}>Save</Button>
            </div>
          </div>
        ) : (
          <>
            <h2 className="text-xl font-black text-white">{user.username}</h2>
            <p className="text-sm text-muted-foreground">{user.phone}</p>
            {user.isAdmin && (
              <span className="mt-2 bg-purple-600/20 text-purple-400 text-xs font-bold px-3 py-1 rounded-full border border-purple-500/20">
                ADMIN
              </span>
            )}
          </>
        )}
      </div>

      {/* Balance + Withdraw */}
      <div className="px-4 mb-3">
        <div className="bg-gradient-to-r from-purple-900/40 to-purple-800/20 border border-purple-500/20 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase font-bold">Wallet Balance</p>
              <p className="text-2xl font-black text-white">{formatCurrency(user.balance ?? 0)}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-purple-600/20 flex items-center justify-center">
              <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
          </div>
          <button
            onClick={async () => {
              if ((user.balance ?? 0) <= 0) {
                toast({ title: "Balance kam hai!", description: "Pehle ID becho aur admin approval lo", variant: "destructive" });
                return;
              }
              try {
                const token = localStorage.getItem("ff_token");
                const res = await fetch("/api/profile/withdraw", {
                  method: "POST",
                  headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
                });
                if (!res.ok) throw new Error("Withdraw failed");
                const data = await res.json();
                toast({ title: "Withdraw Request Bheja!", description: `${formatCurrency(data.pendingBalance)} ab pending hai. Admin jald payment karega.` });
                queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() });
              } catch (e) {
                toast({ title: "Withdraw nahi ho saka!", description: "Baad mein try karein", variant: "destructive" });
              }
            }}
            className="w-full h-10 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-lg text-sm transition-colors"
          >
            Withdraw Balance
          </button>
          <p className="text-[10px] text-muted-foreground text-center mt-2">Withdraw ke liye Admin se contact karein</p>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 mb-4">
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-3 text-center">
            <p className="text-xl font-black text-white">{soldCount}</p>
            <p className="text-[10px] text-muted-foreground uppercase font-bold">IDs Sold</p>
          </div>
          <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-3 text-center">
            <p className="text-xl font-black text-white">{boughtCount}</p>
            <p className="text-[10px] text-muted-foreground uppercase font-bold">IDs Bought</p>
          </div>
          <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-3 text-center">
            <p className="text-xl font-black text-purple-400">{formatCurrency(totalEarned)}</p>
            <p className="text-[10px] text-muted-foreground uppercase font-bold">Total Earned</p>
          </div>
        </div>
      </div>

      {/* Menu items */}
      <div className="px-4 flex flex-col gap-2">
        <Link href="/my-ids">
          <div className="flex items-center gap-3 p-4 bg-[#1a1625] border border-purple-500/10 rounded-xl hover:border-purple-500/30 transition-all active:scale-[0.98]">
            <div className="w-10 h-10 rounded-lg bg-purple-600/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm">My Listed IDs</p>
              <p className="text-xs text-muted-foreground">{myIds?.length ?? 0} IDs submitted</p>
            </div>
            <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
          </div>
        </Link>

        <Link href="/buy">
          <div className="flex items-center gap-3 p-4 bg-[#1a1625] border border-purple-500/10 rounded-xl hover:border-purple-500/30 transition-all active:scale-[0.98]">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" /></svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm">My Bought IDs</p>
              <p className="text-xs text-muted-foreground">{boughtCount} IDs purchased</p>
            </div>
            <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
          </div>
        </Link>

        <div onClick={() => setEditMode(true)} className="flex items-center gap-3 p-4 bg-[#1a1625] border border-purple-500/10 rounded-xl hover:border-purple-500/30 transition-all active:scale-[0.98] cursor-pointer">
          <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
            <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
          </div>
          <div className="flex-1">
            <p className="font-bold text-sm">Change Profile</p>
            <p className="text-xs text-muted-foreground">Update username or photo</p>
          </div>
          <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
        </div>

        <Link href="/support">
          <div className="flex items-center gap-3 p-4 bg-[#1a1625] border border-purple-500/10 rounded-xl hover:border-purple-500/30 transition-all active:scale-[0.98]">
            <div className="w-10 h-10 rounded-lg bg-orange-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
            </div>
            <div className="flex-1">
              <p className="font-bold text-sm">Customer Service</p>
              <p className="text-xs text-muted-foreground">Chat with support team</p>
            </div>
            <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
          </div>
        </Link>

        {user.isAdmin && (
          <Link href="/admin">
            <div className="flex items-center gap-3 p-4 bg-[#1a1625] border border-purple-500/10 rounded-xl hover:border-purple-500/30 transition-all active:scale-[0.98]">
              <div className="w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                <svg className="w-5 h-5 text-yellow-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
              </div>
              <div className="flex-1">
                <p className="font-bold text-sm text-purple-400">Admin Panel</p>
                <p className="text-xs text-muted-foreground">Manage users and IDs</p>
              </div>
              <svg className="w-5 h-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            </div>
          </Link>
        )}
      </div>

      <div className="px-4 mt-4">
        <Button onClick={handleLogout} variant="outline" className="w-full h-12 border-red-500/20 text-red-400 hover:bg-red-500/10 hover:text-red-400 font-bold">
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
          Logout
        </Button>
      </div>
    </div>
  );
}
