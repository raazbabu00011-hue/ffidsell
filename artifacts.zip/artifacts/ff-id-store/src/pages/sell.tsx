import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useGetMe, getGetMeQueryKey, useSubmitId, getListMyIdsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { clearToken } from "@/lib/auth";
import { calculateSellPrice, formatCurrency } from "@/lib/pricing";

type Step = "platform" | "info";

export default function Sell() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const submitId = useSubmitId();

  const [step, setStep] = useState<Step>("platform");
  const [platform, setPlatform] = useState<"facebook" | "google" | null>(null);
  const [ffLevel, setFfLevel] = useState("");
  const [primeLevel, setPrimeLevel] = useState("");
  const [linkedNumber, setLinkedNumber] = useState("");
  const [fbPassword, setFbPassword] = useState("");
  const [gmailLinked, setGmailLinked] = useState("");
  const [gmailPassword, setGmailPassword] = useState("");
  const [upiId, setUpiId] = useState("");
  const [description, setDescription] = useState("");
  const [agree, setAgree] = useState(false);

  useEffect(() => { if (error) { clearToken(); setLocation("/"); } }, [error, setLocation]);

  const sellPrice = calculateSellPrice(Number(primeLevel) || 0, Number(ffLevel) || 0);

  const handleNext = () => {
    if (!platform) { toast({ title: "Select platform", variant: "destructive" }); return; }
    setStep("info");
  };

  const doSubmit = () => {
    if (!platform) { toast({ title: "Select platform", variant: "destructive" }); return; }
    if (!ffLevel || !primeLevel) { toast({ title: "Fill all required fields", variant: "destructive" }); return; }
    if (sellPrice === 0) { toast({ title: "Prime Level must be 3 or above", variant: "destructive" }); return; }
    if (!agree) { toast({ title: "Please agree to the terms", variant: "destructive" }); return; }

    const autoFfId = platform === "facebook"
      ? `FB-${linkedNumber || "unknown"}`
      : `GG-${gmailLinked || "unknown"}`;

    console.log("Submitting ID:", { platform, ffId: autoFfId, ffLevel: Number(ffLevel), primeLevel: Number(primeLevel) });

    submitId.mutate({
      data: { platform, ffId: autoFfId, ffLevel: Number(ffLevel), primeLevel: Number(primeLevel),
        linkedNumber: linkedNumber || undefined, facebookPassword: fbPassword || undefined,
        gmailLinked: gmailLinked || undefined, gmailPassword: gmailPassword || undefined,
        upiId: upiId || undefined }
    }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMyIdsQueryKey() });
        toast({ title: "Submitted! Admin will verify within 24 hours." });
        setLocation("/my-ids");
      },
      onError: (error) => {
        console.error("Submit error:", error);
        const msg = (error as any)?.message || "Failed to submit";
        toast({ title: "Submit Failed", description: msg, variant: "destructive" });
      },
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("handleSubmit called");
    doSubmit();
  };

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  return (
    <div className="flex flex-col flex-1 pb-6">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4 flex items-center gap-3">
        <button onClick={() => step === "info" ? setStep("platform") : setLocation("/home")} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
        <h1 className="text-lg font-black uppercase tracking-wider">Sell FF ID on Grenaid</h1>
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-purple-500/10">
        <div className={`text-xs font-bold px-2 py-1 rounded ${step === "platform" ? "bg-purple-600 text-white" : "bg-[#1a1625] text-muted-foreground"}`}>Step 1/2</div>
        <div className={`text-xs font-bold px-2 py-1 rounded ${step === "info" ? "bg-purple-600 text-white" : "bg-[#1a1625] text-muted-foreground"}`}>Step 2/2</div>
      </div>

      {step === "platform" && (
        <div className="p-4 flex flex-col gap-5">
          <div>
            <Label className="text-sm font-bold text-white mb-3 block">Linked With</Label>
            <div className="grid grid-cols-2 gap-3">
              <button type="button" onClick={() => setPlatform("facebook")}
                className={`p-4 rounded-xl border-2 font-bold text-sm transition-all flex flex-col items-center gap-2 ${platform === "facebook" ? "border-blue-500 bg-blue-500/10 text-blue-400" : "border-border text-muted-foreground hover:border-blue-500/30"}`}>
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                Facebook
              </button>
              <button type="button" onClick={() => setPlatform("google")}
                className={`p-4 rounded-xl border-2 font-bold text-sm transition-all flex flex-col items-center gap-2 ${platform === "google" ? "border-red-500 bg-red-500/10 text-red-400" : "border-border text-muted-foreground hover:border-red-500/30"}`}>
                <svg className="w-8 h-8" viewBox="0 0 24 24"><path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                Google
              </button>
            </div>
          </div>

          <Button onClick={handleNext} className="w-full h-12 bg-purple-600 hover:bg-purple-700 font-bold text-base" disabled={!platform}>
            Next
          </Button>
        </div>
      )}

      {step === "info" && (
        <form onSubmit={handleSubmit} className="p-4 flex flex-col gap-4">
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label htmlFor="ffLevel" className="text-xs uppercase font-bold text-muted-foreground">FF Level *</Label>
                <Input id="ffLevel" type="number" min={1} max={80} value={ffLevel}
                  onChange={e => setFfLevel(e.target.value)} placeholder="Apna Level" className="mt-1 bg-[#1a1625] border-purple-500/20 h-11" required />
              </div>
              <div>
                <Label className="text-xs uppercase font-bold text-muted-foreground">Prime Level *</Label>
                <Select value={primeLevel} onValueChange={setPrimeLevel}>
                  <SelectTrigger className="mt-1 bg-[#1a1625] border-purple-500/20 h-11">
                    <SelectValue placeholder="Select" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1625] border-purple-500/20">
                    {[1,2,3,4,5,6,7,8].map(l => <SelectItem key={l} value={String(l)}>Prime {l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {platform === "facebook" && (
            <div className="flex flex-col gap-3 p-4 bg-[#1a1625] rounded-xl border border-purple-500/10">
              <p className="text-xs font-bold text-blue-400 uppercase">Facebook Details</p>
              <div>
                <Label htmlFor="linkedNumber" className="text-xs uppercase font-bold text-muted-foreground">Facebook Linked Number</Label>
                <Input id="linkedNumber" value={linkedNumber} onChange={e => setLinkedNumber(e.target.value)} placeholder="9876543210" className="mt-1 bg-[#0f0c17] border-purple-500/20 h-11" />
              </div>
              <div>
                <Label htmlFor="fbPassword" className="text-xs uppercase font-bold text-muted-foreground">Facebook Password</Label>
                <Input id="fbPassword" type="password" value={fbPassword} onChange={e => setFbPassword(e.target.value)} placeholder="Facebook password" className="mt-1 bg-[#0f0c17] border-purple-500/20 h-11" />
              </div>
              <div>
                <Label htmlFor="upiId" className="text-xs uppercase font-bold text-muted-foreground">UPI ID for Payout</Label>
                <Input id="upiId" value={upiId} onChange={e => setUpiId(e.target.value)} placeholder="example@upi" className="mt-1 bg-[#0f0c17] border-purple-500/20 h-11" />
              </div>
            </div>
          )}

          {platform === "google" && (
            <div className="flex flex-col gap-3 p-4 bg-[#1a1625] rounded-xl border border-purple-500/10">
              <p className="text-xs font-bold text-red-400 uppercase">Google Details</p>
              <div>
                <Label htmlFor="gmailLinked" className="text-xs uppercase font-bold text-muted-foreground">Gmail linked to FF</Label>
                <Input id="gmailLinked" type="email" value={gmailLinked} onChange={e => setGmailLinked(e.target.value)} placeholder="your@gmail.com" className="mt-1 bg-[#0f0c17] border-purple-500/20 h-11" />
              </div>
              <div>
                <Label htmlFor="gmailPassword" className="text-xs uppercase font-bold text-muted-foreground">Gmail Password</Label>
                <Input id="gmailPassword" type="password" value={gmailPassword} onChange={e => setGmailPassword(e.target.value)} placeholder="Gmail password" className="mt-1 bg-[#0f0c17] border-purple-500/20 h-11" />
              </div>
              <div>
                <Label htmlFor="upiId" className="text-xs uppercase font-bold text-muted-foreground">UPI ID for Payout</Label>
                <Input id="upiId" value={upiId} onChange={e => setUpiId(e.target.value)} placeholder="example@upi" className="mt-1 bg-[#0f0c17] border-purple-500/20 h-11" />
              </div>
            </div>
          )}

          <div>
            <Label htmlFor="desc" className="text-xs uppercase font-bold text-muted-foreground">Description (Optional)</Label>
            <Input id="desc" value={description} onChange={e => setDescription(e.target.value)} placeholder="Good Collection, Rare Bundles, High Level" className="mt-1 bg-[#1a1625] border-purple-500/20 h-11" />
          </div>

          {/* Price preview */}
          <div className="bg-[#1a1625] border border-purple-500/20 rounded-xl p-4">
            <p className="text-xs uppercase font-bold text-muted-foreground mb-2">Estimated Price</p>
            {sellPrice > 0 ? (
              <div className="flex flex-col gap-2">
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Sell Price</span>
                  <span className="text-xl font-black text-white">{formatCurrency(sellPrice)}</span>
                </div>
              </div>
            ) : (
              <p className="text-sm text-red-400 font-medium">Not eligible for sale (Prime Level must be 3+)</p>
            )}
          </div>

          {/* Terms */}
          <label className="flex items-start gap-2 text-xs text-muted-foreground cursor-pointer">
            <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} className="mt-0.5 accent-purple-600" />
            <span>I agree to all the terms and conditions</span>
          </label>

          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 text-xs text-yellow-400">
            <p className="font-bold mb-0.5">Important:</p>
            <p>After admin approval, payment will be sent to your provided UPI ID. Admin will check all details.</p>
          </div>

          <Button type="button" onClick={doSubmit} className="w-full h-12 bg-purple-600 hover:bg-purple-700 font-bold text-base" disabled={submitId.isPending}>
            {submitId.isPending ? "Submitting..." : "Submit ID"}
          </Button>
        </form>
      )}
    </div>
  );
}
