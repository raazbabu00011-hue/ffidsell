import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import InstallPrompt from "@/components/InstallPrompt";

export default function Landing() {
  const [, setLocation] = useLocation();
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });

  useEffect(() => {
    if (user) setLocation("/home");
  }, [user, setLocation]);

  return (
    <div className="flex flex-col flex-1 bg-gradient-radial-purple relative overflow-hidden">
      {/* Decorative glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[300px] h-[300px] rounded-full bg-purple-600/20 blur-[100px]" />

      {/* Hero section */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 relative z-10">
        {/* Character illustration placeholder */}
        <div className="w-48 h-48 rounded-2xl bg-gradient-to-br from-purple-600/30 to-purple-900/50 border border-purple-500/20 flex items-center justify-center mb-6 glow-purple">
          <div className="text-6xl font-black text-purple-400">FF</div>
        </div>

        <h1 className="text-3xl font-black uppercase tracking-wider text-white mb-1">GRENAID</h1>
        <p className="text-sm text-muted-foreground mb-10">Buy & Sell Trusted Free Fire ID on Grenaid</p>

        <div className="w-full max-w-sm flex flex-col gap-3">
          <Button
            variant="outline"
            className="w-full h-12 bg-white text-black hover:bg-gray-100 font-bold border-0"
            onClick={() => setLocation("/login")}
          >
            <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24"><path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </Button>

          <Button
            variant="outline"
            className="w-full h-12 bg-[#1877F2] text-white hover:bg-[#166fe5] font-bold border-0"
            onClick={() => setLocation("/login")}
          >
            <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
            Continue with Facebook
          </Button>

          <Button
            className="w-full h-12 bg-purple-600 hover:bg-purple-700 font-bold"
            onClick={() => setLocation("/login")}
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>
            Login with Mobile Number
          </Button>
        </div>
      </div>

      <div className="text-center pb-8 text-sm text-muted-foreground relative z-10">
        <p className="mb-1">Don't have an account? <Link href="/register" className="text-purple-400 font-bold hover:underline">Register</Link></p>
        <p className="text-xs text-purple-400/60 mt-2">Phone ke browser mein open karo → Share → "Add to Home Screen"</p>
      </div>

      <InstallPrompt />
    </div>
  );
}
