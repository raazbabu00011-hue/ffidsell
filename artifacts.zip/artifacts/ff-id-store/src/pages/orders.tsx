import { useGetMe, getGetMeQueryKey, useListMyIds, getListMyIdsQueryKey } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { clearToken } from "@/lib/auth";
import { formatCurrency } from "@/lib/pricing";

export default function Orders() {
  const [, setLocation] = useLocation();
  const { data: user, isLoading: userLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: myIds, isLoading: idsLoading } = useListMyIds({ query: { queryKey: getListMyIdsQueryKey() } });

  useEffect(() => { if (error) { clearToken(); setLocation("/"); } }, [error, setLocation]);

  if (userLoading || idsLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  return (
    <div className="flex flex-col flex-1 pb-6">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4">
        <h1 className="text-lg font-black uppercase tracking-wider">My Orders</h1>
        <p className="text-xs text-muted-foreground mt-1">Track your listed IDs & purchases</p>
      </div>

      <div className="p-4 flex flex-col gap-4">
        {/* Listed IDs */}
        <div>
          <p className="text-xs font-bold text-muted-foreground uppercase mb-2">Listed IDs ({myIds?.length || 0})</p>
          {myIds && myIds.length > 0 ? (
            myIds.map((id) => (
              <div key={id.id} className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-3 mb-2">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-bold text-sm text-white">{id.ffId}</p>
                    <p className="text-xs text-muted-foreground">{id.platform} · Level {id.ffLevel} · Prime {id.primeLevel}</p>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase ${
                    id.status === "approved" ? "bg-green-500/20 text-green-400" :
                    id.status === "sold" ? "bg-blue-500/20 text-blue-400" :
                    "bg-yellow-500/20 text-yellow-400"
                  }`}>{id.status}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs text-muted-foreground">Sell Price</span>
                  <span className="font-bold text-white">{formatCurrency(id.sellPrice)}</span>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground border border-dashed border-purple-500/20 rounded-xl">
              <p className="font-bold mb-1">No orders yet</p>
              <p className="text-sm">Sell your FF ID to get started</p>
            </div>
          )}
        </div>

        {/* Balance Cards */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-4">
            <p className="text-xs font-bold text-muted-foreground uppercase mb-1">Available</p>
            <p className="text-xl font-black text-white">{formatCurrency(user.balance || 0)}</p>
          </div>
          <div className="bg-[#1a1625] border border-yellow-500/20 rounded-xl p-4">
            <p className="text-xs font-bold text-yellow-500/80 uppercase mb-1">Pending</p>
            <p className="text-xl font-black text-yellow-400">{formatCurrency(user.pendingBalance || 0)}</p>
          </div>
        </div>

        {/* Info */}
        <div className="bg-purple-500/5 border border-purple-500/10 rounded-xl p-3">
          <p className="text-xs text-muted-foreground">
            <span className="font-bold text-purple-400">Note:</span> Withdraw karne par balance Pending mein chala jata hai. Admin approve karega.
          </p>
        </div>
      </div>
    </div>
  );
}
