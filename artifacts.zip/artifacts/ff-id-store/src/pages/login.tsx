import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useLogin } from "@workspace/api-client-react";
import { setToken } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

type LoginMethod = "phone" | "email";

export default function Login() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const login = useLogin();

  const [method, setMethod] = useState<LoginMethod>("phone");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password) return;

    const data: any = { password };
    if (method === "phone") {
      if (!phone) return;
      data.phone = phone;
    } else {
      if (!email) return;
      data.email = email;
    }

    login.mutate(
      { data },
      {
        onSuccess: (res) => {
          setToken(res.token);
          toast({ title: "Welcome back!" });
          setLocation("/home");
        },
        onError: (err: any) => {
          toast({ title: "Login failed", description: err.message, variant: "destructive" });
        }
      }
    );
  };

  return (
    <div className="flex flex-col flex-1 bg-gradient-radial-purple">
      <div className="sticky top-0 z-10 p-4 flex items-center">
        <button onClick={() => setLocation("/")} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center px-6 pb-12">
        <div className="w-full max-w-sm mx-auto space-y-6">
          <div className="text-center">
            <h1 className="text-2xl font-black uppercase tracking-wider text-white mb-1">Login</h1>
            <p className="text-muted-foreground text-sm">Welcome back to Grenaid</p>
          </div>

          {/* Method selector */}
          <div className="grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setMethod("phone")}
              className={`py-2.5 rounded-xl border-2 text-xs font-black uppercase transition-all ${method === "phone" ? "border-purple-500 bg-purple-500/10 text-purple-400" : "border-purple-500/10 text-muted-foreground hover:border-purple-500/30"}`}>
              Phone
            </button>
            <button type="button" onClick={() => setMethod("email")}
              className={`py-2.5 rounded-xl border-2 text-xs font-black uppercase transition-all ${method === "email" ? "border-purple-500 bg-purple-500/10 text-purple-400" : "border-purple-500/10 text-muted-foreground hover:border-purple-500/30"}`}>
              Email
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {method === "phone" && (
              <div className="space-y-1.5">
                <Label htmlFor="phone" className="text-xs uppercase font-bold text-muted-foreground">Mobile Number</Label>
                <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Enter phone number" className="bg-[#1a1625] border-purple-500/20 h-12" required />
              </div>
            )}

            {method === "email" && (
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs uppercase font-bold text-muted-foreground">Email Address</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="your@email.com" className="bg-[#1a1625] border-purple-500/20 h-12" required />
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-xs uppercase font-bold text-muted-foreground">Password</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter password" className="bg-[#1a1625] border-purple-500/20 h-12" required />
            </div>

            <Button type="submit" className="w-full h-12 bg-purple-600 hover:bg-purple-700 font-bold text-base mt-2" disabled={login.isPending}>
              {login.isPending ? "Logging in..." : "Login"}
            </Button>
          </form>

          <div className="text-center text-sm text-muted-foreground">
            Don't have an account? <Link href="/register" className="text-purple-400 font-bold hover:underline">Register</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
