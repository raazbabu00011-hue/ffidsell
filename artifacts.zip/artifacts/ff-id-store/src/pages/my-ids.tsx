import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useGetMe, getGetMeQueryKey, useListMyIds, getListMyIdsQueryKey } from "@workspace/api-client-react";
import { clearToken } from "@/lib/auth";
import { formatCurrency } from "@/lib/pricing";

function StatusBadge({ status }: { status: string }) {
  const classes: Record<string, string> = {
    pending: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    approved: "bg-green-500/20 text-green-400 border-green-500/30",
    sold: "bg-gray-500/20 text-gray-400 border-gray-500/30",
  };
  return (
    <span className={`text-xs font-bold uppercase px-2 py-1 rounded border ${classes[status] || classes.pending}`}>
      {status}
    </span>
  );
}

export default function MyIds() {
  const [, setLocation] = useLocation();
  const { data: user, isLoading: userLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: ids, isLoading: idsLoading } = useListMyIds({ query: { queryKey: getListMyIdsQueryKey() } });

  useEffect(() => {
    if (error) { clearToken(); setLocation("/"); }
  }, [error, setLocation]);

  if (userLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  return (
    <div className="flex flex-col flex-1 pb-6">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4 flex items-center gap-3">
        <button onClick={() => setLocation("/profile")} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
        <h1 className="text-lg font-black uppercase tracking-wider">My Listed IDs</h1>
      </div>

      <div className="p-4 flex flex-col gap-3">
        {idsLoading ? (
          <div className="text-center py-10 text-muted-foreground text-sm">Loading...</div>
        ) : ids && ids.length > 0 ? (
          ids.map(id => (
            <div key={id.id} className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-4 flex flex-col gap-3">
              <div className="flex justify-between items-start">
                <div>
                  <span className={`text-xs font-bold uppercase px-2 py-0.5 rounded ${id.platform === "facebook" ? "bg-blue-500/20 text-blue-400" : "bg-red-500/20 text-red-400"}`}>
                    {id.platform}
                  </span>
                  <p className="font-mono font-bold text-white mt-1 text-sm">{id.ffId}</p>
                </div>
                <StatusBadge status={id.status} />
              </div>
              <div className="flex gap-4 text-sm border-t border-purple-500/10 pt-3">
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Level</p>
                  <p className="font-bold text-white">{id.ffLevel}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase">Prime</p>
                  <p className="font-bold text-white">{id.primeLevel}</p>
                </div>
                <div className="ml-auto text-right">
                  <p className="text-xs text-muted-foreground uppercase">Sell Price</p>
                  <p className="font-bold text-purple-400">{formatCurrency(id.sellPrice)}</p>
                </div>
              </div>
              {id.status === "pending" && (
                <p className="text-xs text-yellow-400/80">Admin will verify within 24 hours.</p>
              )}
            </div>
          ))
        ) : (
          <div className="text-center py-16 text-muted-foreground border border-dashed border-purple-500/20 rounded-xl">
            <p className="font-bold mb-1">No submissions yet</p>
            <p className="text-sm">Start by selling your FF ID on Grenaid.</p>
            <Link href="/sell" className="mt-4 inline-block text-purple-400 font-bold text-sm underline underline-offset-4">
              Sell an ID
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
