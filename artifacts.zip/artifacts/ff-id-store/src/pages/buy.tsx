import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useGetMe, getGetMeQueryKey, useListIds, getListIdsQueryKey, useGetId, getGetIdQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { clearToken } from "@/lib/auth";
import { formatCurrency } from "@/lib/pricing";

type Filter = "all" | "1-3" | "4-6" | "7-8";

export default function Buy() {
  const [, setLocation] = useLocation();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [filter, setFilter] = useState<Filter>("all");

  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: ids, isLoading: isIdsLoading } = useListIds({ query: { queryKey: getListIdsQueryKey() } });
  const { data: selectedDetail } = useGetId(selectedId ?? 0, { query: { queryKey: getGetIdQueryKey(selectedId ?? 0), enabled: !!selectedId } });

  useEffect(() => { if (error) { clearToken(); setLocation("/"); } }, [error, setLocation]);
  useEffect(() => { if (!isLoading && !user) setLocation("/"); }, [isLoading, user, setLocation]);

  const filteredIds = ids?.filter(id => {
    if (filter === "all") return true;
    if (filter === "1-3") return id.primeLevel >= 1 && id.primeLevel <= 3;
    if (filter === "4-6") return id.primeLevel >= 4 && id.primeLevel <= 6;
    if (filter === "7-8") return id.primeLevel >= 7 && id.primeLevel <= 8;
    return true;
  });

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  // Detail view
  if (selectedId && selectedDetail) {
    return (
      <div className="flex flex-col flex-1 pb-6">
        <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4 flex items-center gap-3">
          <button onClick={() => setSelectedId(null)} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
            Back
          </button>
          <h1 className="text-lg font-black uppercase tracking-wider">Buy FF ID on Grenaid</h1>
        </div>

        <div className="p-4 flex flex-col gap-4">
          <div className={`inline-self-start text-xs font-bold uppercase px-3 py-1 rounded w-fit ${selectedDetail.platform === "facebook" ? "bg-blue-500/20 text-blue-400" : "bg-red-500/20 text-red-400"}`}>
            {selectedDetail.platform}
          </div>

          <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-5 flex flex-col gap-4">
            <div>
              <p className="text-xs uppercase font-bold text-muted-foreground">FF ID</p>
              <p className="font-mono text-2xl font-black text-white mt-1">{selectedDetail.ffId}</p>
            </div>
            <div className="grid grid-cols-2 gap-4 border-t border-purple-500/10 pt-4">
              <div>
                <p className="text-xs uppercase font-bold text-muted-foreground">FF Level</p>
                <p className="text-2xl font-black text-white">{selectedDetail.ffLevel}</p>
              </div>
              <div>
                <p className="text-xs uppercase font-bold text-muted-foreground">Prime Level</p>
                <p className="text-2xl font-black text-purple-400">{selectedDetail.primeLevel}</p>
              </div>
            </div>
            <div className="border-t border-purple-500/10 pt-4">
              <p className="text-xs uppercase font-bold text-muted-foreground">Buy Price</p>
              <p className="text-4xl font-black text-white mt-1">{formatCurrency(selectedDetail.buyPrice)}</p>
            </div>
          </div>

          <div className="bg-[#1a1625] rounded-xl p-4 border border-purple-500/10 text-sm text-muted-foreground flex flex-col gap-2">
            <p className="font-bold text-white text-xs uppercase">How to Buy</p>
            <p>1. Click "Buy Now" below</p>
            <p>2. Contact our customer service</p>
            <p>3. Make payment and receive ID details</p>
          </div>

          <Button onClick={() => setLocation("/support")} className="w-full h-14 text-lg font-black uppercase tracking-wider bg-purple-600 hover:bg-purple-700">
            Buy Now
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col flex-1 pb-6">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4">
        <h1 className="text-lg font-black uppercase tracking-wider mb-3">Buy FF ID on Grenaid</h1>
        {/* Filters */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          {(["all", "1-3", "4-6", "7-8"] as Filter[]).map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${filter === f ? "bg-purple-600 text-white" : "bg-[#1a1625] text-muted-foreground border border-purple-500/10"}`}>
              {f === "all" ? "All" : f === "1-3" ? "Prime 1-3" : f === "4-6" ? "Prime 4-6" : "Prime 7-8"}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 flex flex-col gap-3">
        {isIdsLoading ? (
          <div className="text-center py-10 text-muted-foreground text-sm">Loading...</div>
        ) : filteredIds && filteredIds.length > 0 ? (
          filteredIds.map(id => (
            <button key={id.id} onClick={() => setSelectedId(id.id)} className="w-full text-left">
              <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-4 flex gap-3 hover:border-purple-500/30 transition-all active:scale-[0.98]">
                {/* Avatar placeholder */}
                <div className="w-16 h-16 rounded-lg bg-purple-600/10 border border-purple-500/10 flex items-center justify-center flex-shrink-0">
                  <span className="text-xl font-black text-purple-400">{id.primeLevel}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300">Prime {id.primeLevel}</span>
                    <span className="text-[10px] font-bold uppercase px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-300">Level {id.ffLevel}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">FF ID: {id.ffId}</p>
                  <p className="text-xs text-muted-foreground">Seller: {id.sellerUsername ?? "Unknown"}</p>
                </div>
                <div className="text-right flex flex-col justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Sell Price</p>
                    <p className="text-sm font-bold text-muted-foreground line-through">{formatCurrency(id.sellPrice)}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Buy Price</p>
                    <p className="text-lg font-black text-white">{formatCurrency(id.buyPrice)}</p>
                  </div>
                </div>
              </div>
            </button>
          ))
        ) : (
          <div className="text-center py-16 text-muted-foreground border border-dashed border-purple-500/20 rounded-xl">
            <p className="font-bold mb-1">No IDs available</p>
            <p className="text-sm">Check back later or browse with different filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
