import { useLocation, Link } from "wouter";
import { useGetId, getGetIdQueryKey, useGetMe, getGetMeQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { formatCurrency } from "@/lib/pricing";
import { useToast } from "@/hooks/use-toast";

interface BuyIdProps {
  params: { id: string };
}

export default function BuyId({ params }: BuyIdProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const id = Number(params.id);

  const { data: ffId, isLoading } = useGetId(id, { query: { queryKey: getGetIdQueryKey(id) } });
  const { data: user } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });

  const handleBuy = () => {
    if (!user) {
      setLocation("/");
      return;
    }
    toast({ title: "Contact us on Customer Service to complete purchase.", duration: 5000 });
    setLocation("/support");
  };

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!ffId) return (
    <div className="flex-1 flex flex-col items-center justify-center gap-4">
      <p className="text-muted-foreground">ID not found</p>
      <button onClick={() => setLocation("/buy")} className="text-purple-400 font-bold">Go Back</button>
    </div>
  );

  return (
    <div className="flex flex-col flex-1 pb-6">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4 flex items-center gap-3">
        <button onClick={() => setLocation("/buy")} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
        <h1 className="text-lg font-black uppercase tracking-wider">Buy FF ID on Grenaid</h1>
      </div>

      <div className="p-4 flex flex-col gap-4">
        <div className={`inline-self-start text-xs font-bold uppercase px-3 py-1 rounded w-fit ${ffId.platform === "facebook" ? "bg-blue-500/20 text-blue-400" : "bg-red-500/20 text-red-400"}`}>
          {ffId.platform}
        </div>

        <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-5 flex flex-col gap-4">
          <div>
            <p className="text-xs uppercase font-bold text-muted-foreground">FF ID</p>
            <p className="font-mono text-2xl font-black text-white mt-1">{ffId.ffId}</p>
          </div>
          <div className="grid grid-cols-2 gap-4 border-t border-purple-500/10 pt-4">
            <div>
              <p className="text-xs uppercase font-bold text-muted-foreground">FF Level</p>
              <p className="text-2xl font-black text-white">{ffId.ffLevel}</p>
            </div>
            <div>
              <p className="text-xs uppercase font-bold text-muted-foreground">Prime Level</p>
              <p className="text-2xl font-black text-purple-400">{ffId.primeLevel}</p>
            </div>
          </div>
          <div className="border-t border-purple-500/10 pt-4 flex items-end justify-between">
            <div>
              <p className="text-xs text-muted-foreground">Sell Price</p>
              <p className="text-sm font-bold text-muted-foreground line-through">{formatCurrency(ffId.sellPrice)}</p>
            </div>
            <div className="text-right">
              <p className="text-xs uppercase font-bold text-muted-foreground">Buy Price</p>
              <p className="text-3xl font-black text-white">{formatCurrency(ffId.buyPrice)}</p>
            </div>
          </div>
        </div>

        <div className="bg-[#1a1625] rounded-xl p-4 border border-purple-500/10 text-sm text-muted-foreground flex flex-col gap-2">
          <p className="font-bold text-white text-xs uppercase">How to Buy</p>
          <p>1. Click "Buy Now" below</p>
          <p>2. Contact our customer service</p>
          <p>3. Make payment and receive the ID</p>
        </div>

        <Button onClick={handleBuy} className="w-full h-14 text-lg font-black uppercase tracking-wider bg-purple-600 hover:bg-purple-700">
          Buy Now
        </Button>
      </div>
    </div>
  );
}
