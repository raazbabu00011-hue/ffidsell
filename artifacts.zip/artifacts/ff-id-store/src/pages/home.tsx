import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useGetMe, getGetMeQueryKey, useListMyIds, getListMyIdsQueryKey } from "@workspace/api-client-react";
import { clearToken } from "@/lib/auth";
import { formatCurrency } from "@/lib/pricing";

const navItems = [
  { path: "/home", label: "Home", icon: (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
  )},
  { path: "/sell", label: "Sell ID", icon: (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
  )},
  { path: "/orders", label: "Orders", icon: (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
  )},
  { path: "/profile", label: "Profile", icon: (
    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
  )},
];

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: ids, isLoading: isIdsLoading } = useListMyIds({ query: { queryKey: getListMyIdsQueryKey() } });

  useEffect(() => {
    if (error) { clearToken(); setLocation("/"); }
  }, [error, setLocation]);

  useEffect(() => {
    if (!isLoading && !user) setLocation("/");
  }, [isLoading, user, setLocation]);

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  return (
    <div className="flex flex-col flex-1 pb-20">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md border-b border-purple-500/10 p-4 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-black uppercase tracking-wider text-white">GRENAID</h1>
          <p className="text-xs text-muted-foreground">SAFE PLATFORM BUY & SELL FF ID ON GRENAID</p>
        </div>
        <button onClick={() => setLocation("/support")} className="w-10 h-10 rounded-full bg-purple-600/20 border border-purple-500/20 flex items-center justify-center text-purple-400">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>
        </button>
      </div>

      <main className="flex-1 p-4 flex flex-col gap-5">
        {/* Hero Banner */}
        <div className="relative rounded-xl overflow-hidden bg-gradient-to-r from-purple-900/80 to-purple-600/40 border border-purple-500/20 p-5">
          <div className="relative z-10">
            <p className="text-xs font-bold text-purple-300 uppercase mb-1">SAFE PLATFORM</p>
            <h2 className="text-xl font-black text-white mb-1">BUY & SELL FF ID ON GRENAID</h2>
            <p className="text-xs text-purple-200/80 mb-3">100% Secure - Fast - Trusted</p>
            <div className="flex gap-2">
              <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded border border-purple-500/20">Verified</span>
              <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded border border-purple-500/20">Fast</span>
            </div>
          </div>
          {/* Decorative character */}
          <div className="absolute right-2 top-1/2 -translate-y-1/2 w-20 h-20 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
            <span className="text-2xl font-black text-purple-400/50">FF</span>
          </div>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 gap-3">
          <Link href="/sell" className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#1a1625] border border-purple-500/10 hover:border-purple-500/30 transition-all active:scale-[0.97]">
            <div className="w-12 h-12 rounded-full bg-purple-600/20 flex items-center justify-center">
              <svg className="w-6 h-6 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
            </div>
            <div className="text-center">
              <p className="text-sm font-bold text-white">Sell ID</p>
              <p className="text-[10px] text-muted-foreground">Sell your FF ID</p>
            </div>
          </Link>

          <Link href="/orders" className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#1a1625] border border-purple-500/10 hover:border-purple-500/30 transition-all active:scale-[0.97]">
            <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
              <svg className="w-6 h-6 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
            </div>
            <div className="text-center">
              <p className="text-sm font-bold text-white">My Orders</p>
              <p className="text-[10px] text-muted-foreground">Track Listings</p>
            </div>
          </Link>

          <Link href="/support" className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#1a1625] border border-purple-500/10 hover:border-purple-500/30 transition-all active:scale-[0.97]">
            <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
              <svg className="w-6 h-6 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
            </div>
            <div className="text-center">
              <p className="text-sm font-bold text-white">Customer Service</p>
              <p className="text-[10px] text-muted-foreground">Contact Support</p>
            </div>
          </Link>

          <Link href="/profile" className="flex flex-col items-center gap-2 p-4 rounded-xl bg-[#1a1625] border border-purple-500/10 hover:border-purple-500/30 transition-all active:scale-[0.97]">
            <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center">
              <svg className="w-6 h-6 text-orange-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            </div>
            <div className="text-center">
              <p className="text-sm font-bold text-white">My Profile</p>
              <p className="text-[10px] text-muted-foreground">View Profile</p>
            </div>
          </Link>
        </div>

        {/* How it Works */}
        <div className="bg-[#1a1625] rounded-xl border border-purple-500/10 p-4">
          <h3 className="text-sm font-bold text-white mb-3">How It Works?</h3>
          <div className="flex items-center gap-2">
            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center border border-purple-500/20">
                <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
              </div>
              <p className="text-[10px] text-muted-foreground text-center">1. Sell ID</p>
            </div>
            <svg className="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center border border-purple-500/20">
                <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <p className="text-[10px] text-muted-foreground text-center">2. Admin Check</p>
            </div>
            <svg className="w-4 h-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
            <div className="flex-1 flex flex-col items-center gap-1">
              <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center border border-purple-500/20">
                <svg className="w-5 h-5 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              </div>
              <p className="text-[10px] text-muted-foreground text-center">3. Get Payment</p>
            </div>
          </div>
        </div>

        {/* Info Banner */}
        <div className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-4">
          <h3 className="text-sm font-bold text-white mb-2">Grenaid ID Selling</h3>
          <p className="text-xs text-muted-foreground leading-relaxed">
            Apna FF ID becho → Admin approve karega → Balance mil jayega → Withdraw kar lo. Sirf verified IDs par payment milta hai.
          </p>
        </div>

        {/* Stats Preview */}
        <div>
          <h3 className="text-sm font-bold text-white mb-3">Your Activity</h3>
          {isIdsLoading ? (
            <div className="text-center py-8 text-muted-foreground text-sm">Loading...</div>
          ) : ids && ids.length > 0 ? (
            <div className="flex flex-col gap-3">
              {ids.slice(0, 3).map(id => (
                <div key={id.id} className="bg-[#1a1625] border border-purple-500/10 rounded-xl p-4 flex items-center gap-3">
                  <div className="w-14 h-14 rounded-lg bg-purple-600/10 border border-purple-500/10 flex items-center justify-center flex-shrink-0">
                    <span className="text-lg font-black text-purple-400">{id.primeLevel}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${id.platform === "facebook" ? "bg-blue-500/20 text-blue-400" : "bg-red-500/20 text-red-400"}`}>
                          {id.platform}
                        </span>
                        <span className="text-[10px] bg-purple-500/20 text-purple-300 px-1.5 py-0.5 rounded">Prime {id.primeLevel}</span>
                      </div>
                      <p className="text-xs text-muted-foreground truncate">FF ID: {id.ffId}</p>
                      <p className="text-xs text-muted-foreground">Level {id.ffLevel}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-muted-foreground">{id.status === "approved" ? "Approved" : id.status === "pending" ? "Pending" : "Sold"}</p>
                      <p className="text-lg font-black text-purple-400">{formatCurrency(id.sellPrice)}</p>
                    </div>
                  </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground text-sm border border-dashed border-purple-500/20 rounded-xl">
              Abhi koi ID nahi. Pehli ID bechne ke liye Sell ID dabaen!
            </div>
          )}
        </div>
      </main>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 max-w-[430px] w-full bg-[#0f0c17]/95 backdrop-blur border-t border-purple-500/10 flex justify-around p-2 pb-safe z-20">
        {navItems.map(item => (
          <Link key={item.path} href={item.path} className="flex flex-col items-center gap-0.5 px-3 py-1 text-purple-400">
            {item.icon}
            <span className="text-[10px] font-bold">{item.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
