import { useState, useEffect, useRef } from "react";
import { useLocation, Link } from "wouter";
import {
  useGetMe, getGetMeQueryKey,
  useListMyMessages, getListMyMessagesQueryKey,
  useSendMessage,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQueryClient } from "@tanstack/react-query";
import { clearToken } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export default function Support() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: messages, isLoading: msgsLoading } = useListMyMessages({ query: { queryKey: getListMyMessagesQueryKey() } });
  const sendMessage = useSendMessage();

  useEffect(() => {
    if (error) { clearToken(); setLocation("/"); }
  }, [error, setLocation]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    sendMessage.mutate({ data: { text: text.trim() } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMyMessagesQueryKey() });
        setText("");
      },
      onError: () => toast({ title: "Failed to send", variant: "destructive" }),
    });
  };

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user) return null;

  return (
    <div className="flex flex-col flex-1 h-[100dvh]">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur border-b border-purple-500/10 p-4 flex items-center gap-3">
        <button onClick={() => setLocation("/profile")} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
        <div>
          <h1 className="text-lg font-black uppercase tracking-wider">Customer Service</h1>
          <p className="text-xs text-muted-foreground">We are here to help you</p>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
        {msgsLoading ? (
          <div className="text-center py-10 text-muted-foreground text-sm">Loading messages...</div>
        ) : messages && messages.length > 0 ? (
          messages.map(msg => (
            <div key={msg.id} className={`flex ${msg.isAdmin ? "justify-start" : "justify-end"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${msg.isAdmin
                ? "bg-[#1a1625] border border-purple-500/10 rounded-tl-sm"
                : "bg-purple-600 text-white rounded-tr-sm"}`}>
                {msg.isAdmin && (
                  <p className="text-xs font-bold uppercase text-purple-400 mb-1">Admin</p>
                )}
                <p className="text-sm">{msg.text}</p>
                <p className={`text-xs mt-1 ${msg.isAdmin ? "text-muted-foreground" : "text-purple-200/70"}`}>
                  {new Date(msg.createdAt).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
            <p className="font-bold mb-1">No messages yet</p>
            <p className="text-sm">Send a message to get support from our team.</p>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="sticky bottom-0 bg-[#0f0c17] border-t border-purple-500/10 p-4 flex gap-2">
        <Input
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Type your message..."
          className="flex-1 bg-[#1a1625] border-purple-500/20"
        />
        <Button type="submit" disabled={sendMessage.isPending || !text.trim()} className="font-bold px-5 bg-purple-600 hover:bg-purple-700">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
        </Button>
      </form>
    </div>
  );
}
