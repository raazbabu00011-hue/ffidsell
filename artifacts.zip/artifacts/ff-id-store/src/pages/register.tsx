import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useRegister } from "@workspace/api-client-react";
import { setToken } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

type RegMethod = "phone" | "email" | "google";

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const register = useRegister();

  const [method, setMethod] = useState<RegMethod>("phone");
  const [username, setUsername] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      toast({ title: "Username and password required", variant: "destructive" });
      return;
    }
    if (password !== confirmPassword) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }

    const data: any = { username, password };
    if (method === "phone") {
      if (!phone) { toast({ title: "Phone number required", variant: "destructive" }); return; }
      data.phone = phone;
    } else if (method === "email") {
      if (!email) { toast({ title: "Email required", variant: "destructive" }); return; }
      data.email = email;
    } else if (method === "google") {
      if (!email) { toast({ title: "Gmail required", variant: "destructive" }); return; }
      data.email = email;
    }

    register.mutate(
      { data },
      {
        onSuccess: (res) => {
          setToken(res.token);
          toast({ title: "Account created successfully!" });
          setLocation("/home");
        },
        onError: (err: any) => {
          toast({ title: "Registration failed", description: err.message, variant: "destructive" });
        }
      }
    );
  };

  return (
    <div className="flex flex-col flex-1 bg-gradient-radial-purple">
      <div className="sticky top-0 z-10 p-4 flex items-center">
        <button onClick={() => setLocation("/")} className="text-muted-foreground hover:text-foreground text-sm flex items-center gap-1">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          Back
        </button>
      </div>

      <div className="flex-1 flex flex-col justify-center px-6 pb-12">
        <div className="w-full max-w-sm mx-auto space-y-6">
          <div className="text-center">
            <h1 className="text-2xl font-black uppercase tracking-wider text-white mb-1">Create Account</h1>
            <p className="text-muted-foreground text-sm">Join Grenaid</p>
          </div>

          {/* Method selector */}
          <div className="grid grid-cols-3 gap-2">
            {(["phone", "email", "google"] as RegMethod[]).map((m) => (
              <button key={m} type="button" onClick={() => setMethod(m)}
                className={`py-2.5 rounded-xl border-2 text-xs font-black uppercase transition-all ${method === m ? "border-purple-500 bg-purple-500/10 text-purple-400" : "border-purple-500/10 text-muted-foreground hover:border-purple-500/30"}`}>
                {m === "phone" ? "Phone" : m === "email" ? "Email" : "Google"}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username" className="text-xs uppercase font-bold text-muted-foreground">Full Name</Label>
              <Input id="username" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Enter your name" className="bg-[#1a1625] border-purple-500/20 h-12" required />
            </div>

            {method === "phone" && (
              <div className="space-y-1.5">
                <Label htmlFor="phone" className="text-xs uppercase font-bold text-muted-foreground">Mobile Number</Label>
                <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="Enter mobile number" className="bg-[#1a1625] border-purple-500/20 h-12" required />
              </div>
            )}

            {(method === "email" || method === "google") && (
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs uppercase font-bold text-muted-foreground">{method === "google" ? "Gmail Address" : "Email Address"}</Label>
                <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={method === "google" ? "your@gmail.com" : "your@email.com"} className="bg-[#1a1625] border-purple-500/20 h-12" required />
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-xs uppercase font-bold text-muted-foreground">Password</Label>
              <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Create password" className="bg-[#1a1625] border-purple-500/20 h-12" required />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="confirm" className="text-xs uppercase font-bold text-muted-foreground">Confirm Password</Label>
              <Input id="confirm" type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm password" className="bg-[#1a1625] border-purple-500/20 h-12" required />
            </div>

            <Button type="submit" className="w-full h-12 bg-purple-600 hover:bg-purple-700 font-bold text-base mt-2" disabled={register.isPending}>
              {register.isPending ? "Creating..." : "Register"}
            </Button>
          </form>

          <div className="text-center text-sm text-muted-foreground">
            Already have an account? <Link href="/login" className="text-purple-400 font-bold hover:underline">Login</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
