import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6">
      <div className="w-20 h-20 rounded-full bg-purple-600/10 border border-purple-500/20 flex items-center justify-center mb-4">
        <svg className="w-10 h-10 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
      </div>
      <h1 className="text-2xl font-black text-white mb-1">404</h1>
      <p className="text-sm text-muted-foreground mb-6">Page not found</p>
      <Link href="/" className="px-6 py-3 bg-purple-600 text-white rounded-xl font-bold text-sm hover:bg-purple-700 transition-colors">
        Go Home
      </Link>
    </div>
  );
}
