import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import {
  useGetMe, getGetMeQueryKey,
  useAdminListUsers, getAdminListUsersQueryKey,
  useAdminListIds, getAdminListIdsQueryKey,
  useAdminApproveId,
  useAdminListMessages, getAdminListMessagesQueryKey,
  useAdminReplyMessage,
  getListIdsQueryKey,
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useQueryClient } from "@tanstack/react-query";
import { clearToken } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from "@/lib/pricing";

type Tab = "dashboard" | "users" | "ids" | "withdrawals" | "messages";
type PrimeFilter = "all" | 3 | 4 | 5 | 6 | 7 | 8;

const sidebarItems: { tab: Tab; label: string; icon: string }[] = [
  { tab: "dashboard", label: "Dashboard", icon: "M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" },
  { tab: "users", label: "Users", icon: "M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197m13.5-9a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0z" },
  { tab: "ids", label: "Submitted IDs", icon: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" },
  { tab: "withdrawals", label: "Withdrawals", icon: "M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" },
  { tab: "messages", label: "Messages", icon: "M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" },
];

export default function Admin() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<Tab>("dashboard");
  const [replyText, setReplyText] = useState<Record<number, string>>({});
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [primeFilter, setPrimeFilter] = useState<PrimeFilter>("all");
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [withdrawalsLoading, setWithdrawalsLoading] = useState(false);

  const { data: user, isLoading, error } = useGetMe({ query: { queryKey: getGetMeQueryKey() } });
  const { data: users } = useAdminListUsers({ query: { queryKey: getAdminListUsersQueryKey() } });
  const { data: ids } = useAdminListIds({ query: { queryKey: getAdminListIdsQueryKey() } });
  const { data: messages } = useAdminListMessages({ query: { queryKey: getAdminListMessagesQueryKey() } });

  const approveId = useAdminApproveId();
  const replyMessage = useAdminReplyMessage();

  useEffect(() => { if (error) { clearToken(); setLocation("/"); } }, [error, setLocation]);
  useEffect(() => { if (user && !user.isAdmin) setLocation("/profile"); }, [user, setLocation]);

  useEffect(() => {
    if (tab !== "withdrawals") return;
    setWithdrawalsLoading(true);
    const token = localStorage.getItem("ff_token");
    fetch("/api/admin/withdrawals", { headers: { "Authorization": `Bearer ${token}` } })
      .then(r => r.json())
      .then(data => { setWithdrawals(data); setWithdrawalsLoading(false); })
      .catch(() => setWithdrawalsLoading(false));
  }, [tab]);

  const handleApprove = (id: number, status: "approved" | "rejected") => {
    approveId.mutate({ id, data: { status } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getAdminListIdsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListIdsQueryKey() });
        toast({ title: `ID ${status}` });
      },
      onError: () => toast({ title: "Action failed", variant: "destructive" }),
    });
  };

  const handleReply = (msgId: number) => {
    const text = replyText[msgId]?.trim();
    if (!text) return;
    replyMessage.mutate({ id: msgId, data: { text } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getAdminListMessagesQueryKey() });
        setReplyText(prev => ({ ...prev, [msgId]: "" }));
        toast({ title: "Reply sent" });
      },
      onError: () => toast({ title: "Failed to reply", variant: "destructive" }),
    });
  };

  if (isLoading) return <div className="flex-1 flex items-center justify-center text-muted-foreground">Loading...</div>;
  if (!user?.isAdmin) return null;

  const pendingCount = ids?.filter(i => i.status === "pending").length ?? 0;
  const approvedCount = ids?.filter(i => i.status === "approved").length ?? 0;
  const totalSold = ids?.filter(i => i.status === "sold").length ?? 0;

  const messagesByUser: Record<number, typeof messages> = {};
  if (messages) {
    for (const msg of messages) {
      if (!messagesByUser[msg.userId]) messagesByUser[msg.userId] = [];
      messagesByUser[msg.userId]!.push(msg);
    }
  }

  const primeCounts: Record<number, number> = { 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0 };
  ids?.forEach(id => { if (primeCounts[id.primeLevel] !== undefined) primeCounts[id.primeLevel]++; });

  const filteredIds = primeFilter === "all" ? ids : ids?.filter(i => i.primeLevel === primeFilter);

  const navItem = (t: Tab, label: string, icon: string) => (
    <button
      key={t}
      onClick={() => { setTab(t); setSidebarOpen(false); }}
      className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors rounded-lg ${
        tab === t ? "bg-blue-600/20 text-blue-400 border-l-2 border-blue-500" : "text-gray-400 hover:text-white hover:bg-white/5"
      }`}
    >
      <svg className="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={icon} /></svg>
      <span className="hidden sm:inline">{label}</span>
    </button>
  );

  return (
    <div className="flex flex-col flex-1 pb-6 min-h-0">
      {/* Top Bar */}
      <div className="sticky top-0 z-20 bg-[#0d1117]/95 backdrop-blur border-b border-gray-800 p-3 flex items-center gap-3">
        <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 rounded-lg hover:bg-white/5 text-gray-400">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
        </button>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600/20 flex items-center justify-center">
            <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 0010 16a5.986 5.986 0 004.546-2.084A5 5 0 0010 11z" /></svg>
          </div>
          <h1 className="text-sm font-black uppercase tracking-wider text-white">Admin Dashboard</h1>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <span className="text-[10px] text-gray-500">{new Date().toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
          <Link href="/profile" className="p-1.5 rounded-lg hover:bg-white/5 text-gray-400">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          </Link>
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 flex" onClick={() => setSidebarOpen(false)}>
          <div className="w-64 bg-[#0d1117] border-r border-gray-800 p-4 flex flex-col gap-1" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-6 px-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
              </div>
              <div>
                <p className="text-sm font-bold text-white">ADMIN</p>
                <p className="text-[10px] text-green-400 flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-green-400 inline-block"></span>Online</p>
              </div>
            </div>
            <div className="flex flex-col gap-1">
              {sidebarItems.map(s => navItem(s.tab, s.label, s.icon))}
            </div>
            <div className="mt-auto pt-4 border-t border-gray-800">
              <button onClick={() => { clearToken(); setLocation("/"); }} className="w-full flex items-center gap-3 px-4 py-3 text-sm font-medium text-gray-400 hover:text-red-400 rounded-lg hover:bg-red-500/5 transition-colors">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6a2 2 0 012 2v1" /></svg>
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="p-3 flex flex-col gap-3">
        {/* DASHBOARD */}
        {tab === "dashboard" && (
          <div className="flex flex-col gap-3">
            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "Total Users", value: users?.length ?? 0, icon: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z", color: "text-blue-400", bg: "bg-blue-500/10" },
                { label: "Total IDs", value: ids?.length ?? 0, icon: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2", color: "text-purple-400", bg: "bg-purple-500/10" },
                { label: "Pending IDs", value: pendingCount, icon: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z", color: "text-yellow-400", bg: "bg-yellow-500/10" },
                { label: "Approved IDs", value: approvedCount, icon: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z", color: "text-green-400", bg: "bg-green-500/10" },
              ].map((s, i) => (
                <div key={i} className="bg-[#161b22] border border-gray-800 rounded-xl p-3 flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg ${s.bg} flex items-center justify-center flex-shrink-0`}>
                    <svg className={`w-4 h-4 ${s.color}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d={s.icon} /></svg>
                  </div>
                  <div>
                    <p className="text-lg font-black text-white">{s.value}</p>
                    <p className="text-[10px] text-gray-500 uppercase font-bold">{s.label}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Pending Quick Actions */}
            <div className="bg-[#161b22] border border-gray-800 rounded-xl p-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-white uppercase">Pending Approvals</h3>
                <button onClick={() => setTab("ids")} className="text-[10px] text-blue-400 font-bold">View All</button>
              </div>
              <div className="flex flex-col gap-2">
                {ids?.filter(i => i.status === "pending").slice(0, 4).map(id => (
                  <div key={id.id} className="flex items-center justify-between bg-[#0d1117] rounded-lg p-2.5">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded text-[10px] font-bold flex items-center justify-center ${id.platform === "facebook" ? "bg-blue-500/20 text-blue-400" : "bg-red-500/20 text-red-400"}`}>
                        {id.platform[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="text-xs font-bold text-white font-mono">{id.ffId}</p>
                        <p className="text-[10px] text-gray-500">Prime {id.primeLevel} · Level {id.ffLevel}</p>
                      </div>
                    </div>
                    <div className="flex gap-1">
                      <Button size="sm" className="h-6 px-2 text-[10px] font-bold bg-green-600 hover:bg-green-700" onClick={() => handleApprove(id.id, "approved")}>Approve</Button>
                      <Button size="sm" variant="outline" className="h-6 px-2 text-[10px] font-bold border-red-500/30 text-red-400 hover:bg-red-500/10" onClick={() => handleApprove(id.id, "rejected")}>Reject</Button>
                    </div>
                  </div>
                )) ?? <p className="text-xs text-gray-500 text-center py-4">No pending approvals</p>}
              </div>
            </div>
          </div>
        )}

        {/* USERS TAB */}
        {tab === "users" && (
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between px-1">
              <h2 className="text-xs font-bold text-white uppercase">All Users ({users?.length ?? 0})</h2>
            </div>
            {users?.map(u => {
              const userIds = ids?.filter(id => id.sellerUsername === u.username) ?? [];
              const isOpen = selectedUser === u.id;
              return (
                <div key={u.id} className="bg-[#161b22] border border-gray-800 rounded-xl overflow-hidden">
                  <div className="p-3 flex items-center gap-3 cursor-pointer" onClick={() => setSelectedUser(isOpen ? null : u.id)}>
                    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500/30 to-purple-600/30 flex items-center justify-center text-xs font-bold text-white flex-shrink-0">
                      {u.username.substring(0, 2).toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-white truncate">{u.username}</p>
                      <p className="text-[10px] text-gray-500 truncate">{u.phone || u.email || "No contact"}</p>
                    </div>
                    <div className="text-right flex items-center gap-2">
                      <span className="text-[10px] text-gray-500">{userIds.length} IDs</span>
                      <svg className={`w-4 h-4 text-gray-500 transition-transform ${isOpen ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                    </div>
                  </div>
                  {isOpen && (
                    <div className="px-3 pb-3 border-t border-gray-800 pt-2">
                      <div className="grid grid-cols-2 gap-2 mb-2">
                        <div className="bg-[#0d1117] rounded-lg p-2 text-[10px]">
                          <span className="text-gray-500">Phone</span>
                          <p className="text-white font-mono mt-0.5">{u.phone || "N/A"}</p>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-2 text-[10px]">
                          <span className="text-gray-500">Email</span>
                          <p className="text-white font-mono mt-0.5">{u.email || "N/A"}</p>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-2 text-[10px]">
                          <span className="text-gray-500">Balance</span>
                          <p className="text-green-400 font-bold mt-0.5">{formatCurrency(u.balance || 0)}</p>
                        </div>
                        <div className="bg-[#0d1117] rounded-lg p-2 text-[10px]">
                          <span className="text-gray-500">Pending</span>
                          <p className="text-yellow-400 font-bold mt-0.5">{formatCurrency(u.pendingBalance || 0)}</p>
                        </div>
                      </div>
                      <p className="text-[10px] font-bold text-gray-500 uppercase mb-1">Listed IDs ({userIds.length})</p>
                      {userIds.length > 0 ? userIds.map(id => (
                        <div key={id.id} className="bg-[#0d1117] rounded-lg p-2 flex justify-between items-center mb-1 text-[10px]">
                          <div>
                            <p className="font-mono text-white">{id.ffId}</p>
                            <p className="text-gray-500">Prime {id.primeLevel} · Level {id.ffLevel} · {id.platform}</p>
                          </div>
                          <span className={`font-bold px-1.5 py-0.5 rounded ${id.status === "approved" ? "bg-green-500/20 text-green-400" : id.status === "sold" ? "bg-blue-500/20 text-blue-400" : "bg-yellow-500/20 text-yellow-400"}`}>{id.status}</span>
                        </div>
                      )) : <p className="text-[10px] text-gray-500">No IDs listed</p>}
                        {!(u as any).isAdmin && (
                          <button
                            onClick={async (e) => {
                              e.stopPropagation();
                              if (!confirm(`Delete user "${u.username}"? Saari IDs bhi delete ho jayengi!`)) return;
                              const token = localStorage.getItem("ff_token");
                              const res = await fetch(`/api/admin/users/${u.id}`, { method: "DELETE", headers: { "Authorization": `Bearer ${token}` } });
                              if (res.ok) {
                                toast({ title: "User deleted" });
                                queryClient.invalidateQueries({ queryKey: getAdminListUsersQueryKey() });
                                queryClient.invalidateQueries({ queryKey: getAdminListIdsQueryKey() });
                              } else {
                                toast({ title: "Delete failed", variant: "destructive" });
                              }
                            }}
                            className="mt-2 w-full py-1.5 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] font-bold hover:bg-red-500/20 transition-colors"
                          >
                            Delete User & All IDs
                          </button>
                        )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* IDS TAB */}
        {tab === "ids" && (
          <div className="flex flex-col gap-3">
            {/* Prime Filter */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-hide">
              <button onClick={() => setPrimeFilter("all")} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold whitespace-nowrap ${primeFilter === "all" ? "bg-blue-600 text-white" : "bg-[#161b22] text-gray-400 border border-gray-800"}`}>
                ALL <span className="opacity-60 ml-1">{ids?.length ?? 0}</span>
              </button>
              {([3, 4, 5, 6, 7, 8] as const).map(p => (
                <button key={p} onClick={() => setPrimeFilter(p)} className={`px-3 py-1.5 rounded-lg text-[10px] font-bold whitespace-nowrap ${primeFilter === p ? "bg-blue-600 text-white" : "bg-[#161b22] text-gray-400 border border-gray-800"}`}>
                  PRIME {p} <span className="opacity-60 ml-1">{primeCounts[p]}</span>
                </button>
              ))}
            </div>

            {/* ID Cards */}
            <div className="flex flex-col gap-2">
              {filteredIds?.map(id => (
                <div key={id.id} className="bg-[#161b22] border border-gray-800 rounded-xl overflow-hidden">
                  {/* Header row */}
                  <div className="p-3 flex items-start gap-3">
                    <div className={`w-8 h-8 rounded text-[10px] font-bold flex items-center justify-center flex-shrink-0 ${id.platform === "facebook" ? "bg-blue-500/20 text-blue-400" : "bg-red-500/20 text-red-400"}`}>
                      {id.platform === "facebook" ? "FB" : "GG"}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-sm font-bold text-white font-mono">{id.ffId}</p>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase border ${
                          id.status === "approved" ? "text-green-400 border-green-500/30 bg-green-500/10" :
                          id.status === "sold" ? "text-blue-400 border-blue-500/30 bg-blue-500/10" :
                          "text-yellow-400 border-yellow-500/30 bg-yellow-500/10"}`}>{id.status}</span>
                      </div>
                      <p className="text-[10px] text-gray-500">by {id.sellerUsername ?? "Unknown"} · Prime {id.primeLevel} · Level {id.ffLevel}</p>
                    </div>
                    <span className="text-sm font-black text-green-400">{formatCurrency(id.sellPrice)}</span>
                  </div>
                  {/* Details */}
                  <div className="px-3 pb-3">
                    <div className="bg-[#0d1117] rounded-lg p-2.5 flex flex-col gap-1.5 text-[10px]">
                      <p className="text-[9px] uppercase font-bold text-gray-500 mb-0.5">Account Details</p>
                      {id.platform === "facebook" && (
                        <>
                          <div className="flex justify-between"><span className="text-gray-500">Linked Number:</span><span className="text-white font-mono">{id.linkedNumber || "N/A"}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">FB Password:</span><span className="text-white font-mono">{id.facebookPassword || "N/A"}</span></div>
                        </>
                      )}
                      {id.platform === "google" && (
                        <>
                          <div className="flex justify-between"><span className="text-gray-500">Gmail:</span><span className="text-white font-mono">{id.gmailLinked || "N/A"}</span></div>
                          <div className="flex justify-between"><span className="text-gray-500">Gmail Password:</span><span className="text-white font-mono">{id.gmailPassword || "N/A"}</span></div>
                        </>
                      )}
                      <div className="flex justify-between"><span className="text-gray-500">UPI ID:</span><span className="text-green-400 font-mono">{id.upiId || "N/A"}</span></div>
                    </div>
                    <div className="flex gap-2 mt-2">
                      {id.status === "pending" && (
                        <>
                          <Button size="sm" className="flex-1 h-7 text-[10px] font-bold bg-green-600 hover:bg-green-700" onClick={() => handleApprove(id.id, "approved")} disabled={approveId.isPending}>Approve</Button>
                          <Button size="sm" variant="outline" className="flex-1 h-7 text-[10px] font-bold border-red-500/30 text-red-400 hover:bg-red-500/10" onClick={() => handleApprove(id.id, "rejected")} disabled={approveId.isPending}>Reject</Button>
                        </>
                      )}
                      <button
                        onClick={async () => {
                          if (!confirm(`Delete ID "${id.ffId}"? Ye permanently delete ho jayegi!`)) return;
                          const token = localStorage.getItem("ff_token");
                          const res = await fetch(`/api/admin/ids/${id.id}`, { method: "DELETE", headers: { "Authorization": `Bearer ${token}` } });
                          if (res.ok) {
                            toast({ title: "ID deleted" });
                            queryClient.invalidateQueries({ queryKey: getAdminListIdsQueryKey() });
                          } else {
                            toast({ title: "Delete failed", variant: "destructive" });
                          }
                        }}
                        className="flex-1 h-7 rounded-md bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] font-bold hover:bg-red-500/20 transition-colors"
                      >
                        Delete ID
                      </button>
                    </div>
                  </div>
                </div>
              )) ?? <div className="text-center py-8 text-gray-500 text-sm">No IDs in this category</div>}
            </div>
          </div>
        )}

        {/* WITHDRAWALS TAB */}
        {tab === "withdrawals" && (
          withdrawalsLoading ? (
            <div className="text-center py-8 text-gray-500">Loading...</div>
          ) : withdrawals.length > 0 ? (
            withdrawals.map(w => (
              <div key={w.id} className="bg-[#161b22] border border-yellow-500/20 rounded-xl p-3 mb-2">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-yellow-500/30 to-orange-600/30 flex items-center justify-center text-xs font-bold text-yellow-400">
                      {w.username.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">{w.username}</p>
                      <p className="text-[10px] text-gray-500">{w.phone || w.email || "No contact"}</p>
                    </div>
                  </div>
                  <span className="text-lg font-black text-yellow-400">{formatCurrency(w.pendingBalance || 0)}</span>
                </div>
                <Button size="sm" className="w-full h-8 text-xs font-bold bg-green-600 hover:bg-green-700" onClick={async () => {
                  const token = localStorage.getItem("ff_token");
                  await fetch(`/api/admin/withdrawals/${w.id}/approve`, { method: "POST", headers: { "Authorization": `Bearer ${token}` } });
                  toast({ title: "Withdrawal marked as Paid" });
                  setWithdrawals(prev => prev.filter(x => x.id !== w.id));
                }}>Mark as Paid</Button>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-gray-500 text-sm">No pending withdrawals</div>
          )
        )}

        {/* MESSAGES TAB */}
        {tab === "messages" && (
          Object.keys(messagesByUser).length > 0 ? (
            Object.entries(messagesByUser).map(([userId, msgs]) => {
              if (!msgs || msgs.length === 0) return null;
              const lastMsg = msgs[msgs.length - 1]!;
              const lastUserMsgId = [...msgs].reverse().find(m => !m.isAdmin)?.id;
              return (
                <div key={userId} className="bg-[#161b22] border border-gray-800 rounded-xl p-3 flex flex-col gap-2">
                  <div className="flex justify-between items-center pb-2 border-b border-gray-800">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-blue-500/20 flex items-center justify-center text-[10px] font-bold text-blue-400">
                        {msgs[0]?.senderName?.substring(0, 2).toUpperCase() ?? "U"}
                      </div>
                      <p className="font-bold text-sm text-white">{msgs[0]?.senderName ?? "User"}</p>
                    </div>
                    <p className="text-[10px] text-gray-500">{new Date(lastMsg.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div className="flex flex-col gap-2 max-h-48 overflow-y-auto">
                    {msgs.map(msg => (
                      <div key={msg.id} className={`text-xs p-2 rounded-lg ${msg.isAdmin ? "bg-blue-600/10 text-blue-300 border border-blue-500/20 ml-6" : "bg-[#0d1117] border border-gray-800 mr-6"}`}>
                        <p className="text-[9px] font-bold uppercase text-gray-500 mb-0.5">{msg.isAdmin ? "Admin" : msg.senderName}</p>
                        {msg.text}
                      </div>
                    ))}
                  </div>
                  {lastUserMsgId && (
                    <div className="flex gap-2 pt-1 border-t border-gray-800">
                      <Input
                        value={replyText[lastUserMsgId] ?? ""}
                        onChange={e => setReplyText(prev => ({ ...prev, [lastUserMsgId]: e.target.value }))}
                        placeholder="Reply..."
                        className="flex-1 h-8 text-xs bg-[#0d1117] border-gray-800"
                      />
                      <Button size="sm" className="h-8 px-3 text-xs font-bold bg-blue-600 hover:bg-blue-700" onClick={() => handleReply(lastUserMsgId)} disabled={replyMessage.isPending}>Send</Button>
                    </div>
                  )}
                </div>
              );
            })
          ) : <div className="text-center py-8 text-gray-500 text-sm">No messages yet</div>
        )}
      </div>
    </div>
  );
}
