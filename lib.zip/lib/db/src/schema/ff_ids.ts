import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

export const ffIdsTable = pgTable("ff_ids", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  platform: text("platform").notNull(), // 'facebook' | 'google'
  ffId: text("ff_id").notNull(),
  ffLevel: integer("ff_level").notNull(),
  primeLevel: integer("prime_level").notNull(),
  linkedNumber: text("linked_number"),
  facebookPassword: text("facebook_password"),
  uid: text("uid"),
  gmailLinked: text("gmail_linked"),
  gmailPassword: text("gmail_password"),
  upiId: text("upi_id"),
  sellPrice: integer("sell_price").notNull(),
  buyPrice: integer("buy_price").notNull(),
  status: text("status").notNull().default("pending"), // 'pending' | 'approved' | 'sold'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertFfIdSchema = createInsertSchema(ffIdsTable).omit({ id: true, createdAt: true, status: true });
export type InsertFfId = z.infer<typeof insertFfIdSchema>;
export type FfId = typeof ffIdsTable.$inferSelect;
